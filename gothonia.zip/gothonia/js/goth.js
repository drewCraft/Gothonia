function rand(min,max) { return Math.abs(parseInt(Math.random()*(max-(min-1)+(min))) }


document.onload = function () {


  // releaving pattern Game obj. includes all functions and vars
  var Game = {
    // all avalible card to earn
    cards: {
      // all card with a basic rarity
      basic: {
        'hydrogen': [1,rand(1,3),rand(-1,1.5)]
      },
      // all cards with a uncomman rarity
      uncomman: {

      },
      // alll cards with a extreme rarity
      extreme: {

      }
    },

    // round inits


  }

  //  {
  //   // tag containing everyting in the game V
  //   var game_board getElementById('game-board');
  //
  //   // prototype
  //   var player = {
  //     //grave yard
  //     grave:
  //   }
  //     //all tags defined up front
  //   var getElementById('p1-grave');
  //   var
  // };



}
